from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    accounts = db.relationship('Account', backref='user', lazy=True)
    transactions = db.relationship('Transaction', backref='user', lazy=True)
    loans = db.relationship('Loan', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password, method='pbkdf2:sha256')
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Account(db.Model):
    __tablename__ = 'accounts'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(20), nullable=False)  # cash, bank, mobile
    balance = db.Column(db.Float, default=0.0)
    currency = db.Column(db.String(10), default='SAR')
    
    transactions = db.relationship('Transaction', backref='account', lazy=True, foreign_keys='Transaction.account_id')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'type': self.type,
            'balance': self.balance,
            'currency': self.currency
        }


class Transaction(db.Model):
    __tablename__ = 'transactions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    date = db.Column(db.Date, nullable=False, default=datetime.utcnow)
    amount = db.Column(db.Float, nullable=False)
    type = db.Column(db.String(20), nullable=False)  # income, expense, transfer
    category = db.Column(db.String(50), nullable=False)
    account_id = db.Column(db.Integer, db.ForeignKey('accounts.id'), nullable=False)
    to_account_id = db.Column(db.Integer, db.ForeignKey('accounts.id'), nullable=True)  # For transfers
    description = db.Column(db.String(255), default='')
    is_recurring = db.Column(db.Boolean, default=False)
    recurring_frequency = db.Column(db.String(20), nullable=True)  # weekly, monthly
    
    to_account = db.relationship('Account', foreign_keys=[to_account_id])
    
    def to_dict(self):
        return {
            'id': self.id,
            'date': self.date.isoformat() if self.date else None,
            'amount': self.amount,
            'type': self.type,
            'category': self.category,
            'account_id': self.account_id,
            'to_account_id': self.to_account_id,
            'description': self.description,
            'is_recurring': self.is_recurring,
            'recurring_frequency': self.recurring_frequency
        }


class Loan(db.Model):
    __tablename__ = 'loans'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    counterparty = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(10), nullable=False)  # given, taken
    principal_amount = db.Column(db.Float, nullable=False)
    outstanding_balance = db.Column(db.Float, nullable=False)
    due_date = db.Column(db.Date, nullable=False)
    interest_rate = db.Column(db.Float, nullable=True)
    emi_amount = db.Column(db.Float, nullable=True)
    status = db.Column(db.String(20), default='active')  # active, settled
    
    def to_dict(self):
        return {
            'id': self.id,
            'counterparty': self.counterparty,
            'type': self.type,
            'principal_amount': self.principal_amount,
            'outstanding_balance': self.outstanding_balance,
            'due_date': self.due_date.isoformat() if self.due_date else None,
            'interest_rate': self.interest_rate,
            'emi_amount': self.emi_amount,
            'status': self.status
        }
