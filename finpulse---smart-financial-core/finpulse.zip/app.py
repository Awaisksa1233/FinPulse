import os
from datetime import datetime, date, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'finpulse-secret-key')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///finpulse.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['REMEMBER_COOKIE_DURATION'] = timedelta(days=30)

# Enable CORS for API routes
CORS(app, resources={r"/api/*": {"origins": "*"}})

from models import db, User, Account, Transaction, Loan
db.init_app(app)

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

# Create tables
with app.app_context():
    db.create_all()


# ============ AUTH ============
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        email = request.form.get('email', '').lower().strip()
        password = request.form.get('password', '')
        remember = request.form.get('remember') == 'on'
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            login_user(user, remember=remember)
            flash('Welcome back!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password.', 'error')
    
    return render_template('auth.html', mode='login')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').lower().strip()
        password = request.form.get('password', '')
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered.', 'error')
            return render_template('auth.html', mode='register')
        
        if len(password) < 6:
            flash('Password must be at least 6 characters.', 'error')
            return render_template('auth.html', mode='register')
        
        user = User(name=name, email=email)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        login_user(user, remember=True)
        flash('Account created! Welcome to FinPulse.', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('auth.html', mode='register')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'success')
    return redirect(url_for('login'))


# ============ DASHBOARD ============
@app.route('/')
@login_required
def dashboard():
    accounts = Account.query.filter_by(user_id=current_user.id).all()
    total_balance = sum(a.balance for a in accounts)
    
    # This month's income/expense
    today = date.today()
    month_start = date(today.year, today.month, 1)
    
    transactions = Transaction.query.filter(Transaction.user_id == current_user.id, Transaction.date >= month_start).all()
    income_this_month = sum(t.amount for t in transactions if t.type == 'income')
    expense_this_month = sum(t.amount for t in transactions if t.type == 'expense')
    
    # Expense by category
    expense_by_category = {}
    for t in Transaction.query.filter_by(user_id=current_user.id, type='expense').all():
        expense_by_category[t.category] = expense_by_category.get(t.category, 0) + t.amount
    
    # Recent transactions
    recent_transactions = Transaction.query.filter_by(user_id=current_user.id).order_by(Transaction.date.desc()).limit(5).all()
    
    return render_template('dashboard.html',
        active_page='dashboard',
        accounts=accounts,
        total_balance=total_balance,
        income_this_month=income_this_month,
        expense_this_month=expense_this_month,
        expense_by_category=expense_by_category,
        recent_transactions=recent_transactions
    )


@app.route('/api/summary')
@login_required
def get_ai_summary():
    from services.groq_service import generate_account_summary
    
    accounts = [a.to_dict() for a in Account.query.filter_by(user_id=current_user.id).all()]
    
    today = date.today()
    month_start = date(today.year, today.month, 1)
    transactions = [t.to_dict() for t in Transaction.query.filter(Transaction.user_id == current_user.id, Transaction.date >= month_start).all()]
    loans = [l.to_dict() for l in Loan.query.filter_by(user_id=current_user.id, status='active').all()]
    
    summary = generate_account_summary(accounts, transactions, loans)
    return jsonify({'summary': summary})


# ============ MOBILE/SHORTCUT API ============
@app.route('/api/ai', methods=['POST'])
def api_ai_transaction():
    """
    AI-powered API endpoint for natural language transaction input.
    
    POST JSON body:
    {
        "text": "Paid 50 for lunch"
    }
    
    Or just send plain text in the body.
    """
    from services.groq_service import process_chat_command
    
    data = request.get_json(silent=True)
    
    if data:
        text = data.get('text', '')
    else:
        # Accept plain text body
        text = request.data.decode('utf-8')
    
    if not text:
        return jsonify({'success': False, 'error': 'No text provided'}), 400
    
    # Get accounts
    accounts = [a.to_dict() for a in Account.query.all()]
    
    if not accounts:
        return jsonify({'success': False, 'error': 'Create an account first'}), 400
    
    # Process with AI
    result = process_chat_command(text, accounts)
    
    action = result.get('action', 'unknown')
    response_msg = result.get('response_message', 'Done.')
    details = result.get('details', {})
    
    if action == 'unknown' or action == 'error':
        return jsonify({'success': False, 'error': response_msg})
    
    try:
        if action == 'transaction':
            t_type = details.get('type', 'expense')
            amount = float(details.get('amount', 0))
            category = details.get('category', 'Other')
            description = details.get('description', '')
            account_id = details.get('account_id') or accounts[0]['id']
            
            account = db.session.get(Account, int(account_id))
            if not account:
                return jsonify({'success': False, 'error': 'Account not found'}), 400
            
            transaction = Transaction(
                date=date.today(),
                amount=amount,
                type=t_type,
                category=category,
                account_id=int(account_id),
                description=description,
                is_recurring=False
            )
            db.session.add(transaction)
            
            if t_type == 'income':
                account.balance += amount
            else:
                account.balance -= amount
            
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': response_msg,
                'amount': amount,
                'category': category,
                'type': t_type,
                'new_balance': account.balance
            })
        
        elif action == 'transfer':
            from_id = details.get('from_account_id')
            to_id = details.get('to_account_id')
            amount = float(details.get('amount', 0))
            
            if from_id and to_id:
                from_acc = db.session.get(Account, int(from_id))
                to_acc = db.session.get(Account, int(to_id))
                
                if from_acc and to_acc:
                    from_acc.balance -= amount
                    to_acc.balance += amount
                    db.session.commit()
                    
                    return jsonify({
                        'success': True,
                        'message': response_msg,
                        'amount': amount
                    })
        
        elif action == 'loan':
            from datetime import timedelta
            
            amount = float(details.get('amount', 0))
            loan_type = details.get('type', 'given')  # given = lent money, taken = borrowed
            counterparty = details.get('counterparty', 'Unknown')
            due_date_str = details.get('due_date')
            account_id = details.get('account_id') or (accounts[0]['id'] if accounts else None)
            
            if due_date_str:
                try:
                    due_date = datetime.strptime(due_date_str, '%Y-%m-%d').date()
                except:
                    due_date = date.today() + timedelta(days=30)
            else:
                due_date = date.today() + timedelta(days=30)
            
            loan = Loan(
                counterparty=counterparty,
                type=loan_type,
                principal_amount=amount,
                outstanding_balance=amount,
                due_date=due_date,
                status='active'
            )
            db.session.add(loan)
            
            # Adjust account balance
            new_balance = None
            if account_id:
                account = db.session.get(Account, int(account_id))
                if account:
                    if loan_type == 'given':
                        # Lent money = money goes out
                        account.balance -= amount
                    else:
                        # Borrowed money = money comes in
                        account.balance += amount
                    new_balance = account.balance
            
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': response_msg,
                'amount': amount,
                'counterparty': counterparty,
                'type': 'receivable' if loan_type == 'given' else 'payable',
                'new_balance': new_balance
            })
        
        return jsonify({'success': True, 'message': response_msg})
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/transaction', methods=['POST'])
def api_add_transaction():
    """
    API endpoint for adding transactions via iOS Shortcuts or external apps.
    
    POST JSON body:
    {
        "amount": 50.00,
        "type": "expense",  // or "income"
        "category": "Food",
        "description": "Lunch",  // optional
        "account": "Cash",  // optional, account name (uses first account if not specified)
        "date": "2024-01-15"  // optional, defaults to today
    }
    """
    data = request.get_json()
    
    if not data:
        return jsonify({'success': False, 'error': 'No JSON data provided'}), 400
    
    # Required fields
    amount = data.get('amount')
    t_type = data.get('type', 'expense')
    category = data.get('category', 'Other')
    
    if not amount:
        return jsonify({'success': False, 'error': 'Amount is required'}), 400
    
    try:
        amount = float(amount)
    except:
        return jsonify({'success': False, 'error': 'Invalid amount'}), 400
    
    # Optional fields
    description = data.get('description', '')
    
    # Parse date
    date_str = data.get('date')
    if date_str:
        try:
            t_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except:
            t_date = date.today()
    else:
        t_date = date.today()
    
    # Find account
    account_name = data.get('account')
    if account_name:
        account = Account.query.filter(Account.name.ilike(f'%{account_name}%')).first()
    else:
        account = Account.query.first()
    
    if not account:
        return jsonify({'success': False, 'error': 'No accounts found. Create an account first.'}), 400
    
    # Create transaction
    transaction = Transaction(
        date=t_date,
        amount=amount,
        type=t_type,
        category=category,
        account_id=account.id,
        description=description,
        is_recurring=False
    )
    db.session.add(transaction)
    
    # Update balance
    if t_type == 'income':
        account.balance += amount
    else:
        account.balance -= amount
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': f'{t_type.capitalize()} of {amount:.2f} SAR recorded',
        'transaction_id': transaction.id,
        'new_balance': account.balance
    })


@app.route('/api/accounts', methods=['GET'])
def api_get_accounts():
    """Get list of accounts for iOS Shortcuts."""
    accounts = Account.query.all()
    return jsonify({
        'accounts': [{'id': a.id, 'name': a.name, 'type': a.type, 'balance': a.balance} for a in accounts]
    })


@app.route('/shortcut')
def shortcut_setup():
    """iOS Shortcut setup guide."""
    server_url = request.host_url.rstrip('/')
    return render_template('shortcut.html', active_page='shortcut', server_url=server_url)


# ============ REPORTS ============
@app.route('/reports')
def reports():
    timeframe = request.args.get('timeframe', 'monthly')
    year = int(request.args.get('year', date.today().year))
    month = int(request.args.get('month', date.today().month))
    
    # Filter transactions
    if timeframe == 'monthly':
        transactions = Transaction.query.filter(
            db.extract('year', Transaction.date) == year,
            db.extract('month', Transaction.date) == month
        ).all()
        date_display = datetime(year, month, 1).strftime('%B %Y')
        
        # Navigation
        prev_month = month - 1 if month > 1 else 12
        prev_year = year if month > 1 else year - 1
        next_month = month + 1 if month < 12 else 1
        next_year = year if month < 12 else year + 1
        prev_url = url_for('reports', timeframe='monthly', year=prev_year, month=prev_month)
        next_url = url_for('reports', timeframe='monthly', year=next_year, month=next_month)
    else:
        transactions = Transaction.query.filter(
            db.extract('year', Transaction.date) == year
        ).all()
        date_display = str(year)
        prev_url = url_for('reports', timeframe='yearly', year=year-1)
        next_url = url_for('reports', timeframe='yearly', year=year+1)
    
    # Calculate totals
    total_income = sum(t.amount for t in transactions if t.type == 'income')
    total_expense = sum(t.amount for t in transactions if t.type == 'expense')
    net_savings = total_income - total_expense
    
    # Category breakdown
    income_by_category = {}
    expense_by_category = {}
    for t in transactions:
        if t.type == 'income':
            income_by_category[t.category] = income_by_category.get(t.category, 0) + t.amount
        elif t.type == 'expense':
            expense_by_category[t.category] = expense_by_category.get(t.category, 0) + t.amount
    
    # Net worth calculation
    accounts = Account.query.all()
    total_cash = sum(a.balance for a in accounts)
    loans = Loan.query.filter_by(status='active').all()
    total_receivables = sum(l.outstanding_balance for l in loans if l.type == 'given')
    total_payables = sum(l.outstanding_balance for l in loans if l.type == 'taken')
    total_assets = total_cash + total_receivables
    net_worth = total_assets - total_payables
    
    return render_template('reports.html',
        active_page='reports',
        timeframe=timeframe,
        year=year,
        month=month,
        date_display=date_display,
        prev_url=prev_url,
        next_url=next_url,
        total_income=total_income,
        total_expense=total_expense,
        net_savings=net_savings,
        income_by_category=income_by_category,
        expense_by_category=expense_by_category,
        net_worth=net_worth,
        total_assets=total_assets,
        total_payables=total_payables
    )


# ============ INCOME ============
@app.route('/income')
def income():
    accounts = Account.query.all()
    transactions = Transaction.query.filter_by(type='income').order_by(Transaction.date.desc()).limit(10).all()
    return render_template('transactions.html',
        active_page='income',
        transaction_type='income',
        accounts=accounts,
        transactions=transactions,
        today=date.today().isoformat()
    )


# ============ EXPENSES ============
@app.route('/expenses')
def expenses():
    accounts = Account.query.all()
    transactions = Transaction.query.filter_by(type='expense').order_by(Transaction.date.desc()).limit(10).all()
    return render_template('transactions.html',
        active_page='expenses',
        transaction_type='expense',
        accounts=accounts,
        transactions=transactions,
        today=date.today().isoformat()
    )


# ============ ADD TRANSACTION ============
@app.route('/transaction/add', methods=['POST'])
def add_transaction():
    # Validate account exists
    account_id_str = request.form.get('account_id')
    if not account_id_str:
        flash('Please create an account first before adding transactions.', 'error')
        return redirect(url_for('accounts'))
    
    account_id = int(account_id_str)
    account = db.session.get(Account, account_id)
    if not account:
        flash('Invalid account. Please select a valid account.', 'error')
        return redirect(url_for('accounts'))
    
    t_type = request.form.get('type')
    amount = float(request.form.get('amount'))
    t_date = datetime.strptime(request.form.get('date'), '%Y-%m-%d').date()
    category = request.form.get('category')
    description = request.form.get('description', '')
    is_recurring = request.form.get('is_recurring') == 'on'
    recurring_frequency = request.form.get('recurring_frequency') if is_recurring else None
    
    # Create transaction
    transaction = Transaction(
        date=t_date,
        amount=amount,
        type=t_type,
        category=category,
        account_id=account_id,
        description=description,
        is_recurring=is_recurring,
        recurring_frequency=recurring_frequency
    )
    db.session.add(transaction)
    
    # Update account balance
    if account:
        if t_type == 'income':
            account.balance += amount
        else:
            account.balance -= amount
    
    db.session.commit()
    flash(f'{t_type.capitalize()} of {amount:.2f} SAR added successfully!', 'success')
    
    return redirect(url_for('income' if t_type == 'income' else 'expenses'))


@app.route('/transaction/edit', methods=['POST'])
def edit_transaction():
    transaction_id = int(request.form.get('id'))
    transaction = db.session.get(Transaction, transaction_id)
    
    if not transaction:
        flash('Transaction not found.', 'error')
        return redirect(url_for('expenses'))
    
    old_amount = transaction.amount
    old_type = transaction.type
    old_account_id = transaction.account_id
    
    # Get new values
    new_amount = float(request.form.get('amount'))
    new_type = request.form.get('type')
    new_date = datetime.strptime(request.form.get('date'), '%Y-%m-%d').date()
    new_category = request.form.get('category')
    new_account_id = int(request.form.get('account_id'))
    new_description = request.form.get('description', '')
    
    # Reverse old balance change
    old_account = db.session.get(Account, old_account_id)
    if old_account:
        if old_type == 'income':
            old_account.balance -= old_amount
        else:
            old_account.balance += old_amount
    
    # Apply new balance change
    new_account = db.session.get(Account, new_account_id)
    if new_account:
        if new_type == 'income':
            new_account.balance += new_amount
        else:
            new_account.balance -= new_amount
    
    # Update transaction
    transaction.amount = new_amount
    transaction.type = new_type
    transaction.date = new_date
    transaction.category = new_category
    transaction.account_id = new_account_id
    transaction.description = new_description
    
    db.session.commit()
    flash('Transaction updated successfully!', 'success')
    
    return redirect(url_for('income' if new_type == 'income' else 'expenses'))


@app.route('/transaction/delete/<int:transaction_id>', methods=['POST'])
def delete_transaction(transaction_id):
    transaction = db.session.get(Transaction, transaction_id)
    
    if transaction:
        # Reverse balance change
        account = db.session.get(Account, transaction.account_id)
        if account:
            if transaction.type == 'income':
                account.balance -= transaction.amount
            else:
                account.balance += transaction.amount
        
        t_type = transaction.type
        db.session.delete(transaction)
        db.session.commit()
        flash('Transaction deleted.', 'success')
        return redirect(url_for('income' if t_type == 'income' else 'expenses'))
    
    flash('Transaction not found.', 'error')
    return redirect(url_for('expenses'))


# ============ ACCOUNTS ============
@app.route('/accounts')
def accounts():
    all_accounts = Account.query.all()
    return render_template('accounts.html',
        active_page='accounts',
        accounts=all_accounts
    )


@app.route('/account/add', methods=['POST'])
def add_account():
    account = Account(
        name=request.form.get('name'),
        type=request.form.get('type'),
        balance=float(request.form.get('balance', 0)),
        currency=request.form.get('currency', 'SAR')
    )
    db.session.add(account)
    db.session.commit()
    flash('Account created successfully!', 'success')
    return redirect(url_for('accounts'))


@app.route('/account/edit', methods=['POST'])
def edit_account():
    account_id = int(request.form.get('id'))
    account = db.session.get(Account, account_id)
    if account:
        account.name = request.form.get('name')
        account.type = request.form.get('type')
        account.balance = float(request.form.get('balance'))
        account.currency = request.form.get('currency')
        db.session.commit()
        flash('Account updated successfully!', 'success')
    return redirect(url_for('accounts'))


@app.route('/account/delete/<int:account_id>', methods=['POST'])
def delete_account(account_id):
    account = db.session.get(Account, account_id)
    if account:
        db.session.delete(account)
        db.session.commit()
        flash('Account deleted.', 'success')
    return redirect(url_for('accounts'))


@app.route('/transfer', methods=['POST'])
def transfer():
    from_id = int(request.form.get('from_id'))
    to_id = int(request.form.get('to_id'))
    amount = float(request.form.get('amount'))
    
    if from_id == to_id:
        flash('Cannot transfer to the same account.', 'error')
        return redirect(url_for('accounts'))
    
    from_acc = db.session.get(Account, from_id)
    to_acc = db.session.get(Account, to_id)
    
    if from_acc and to_acc:
        from_acc.balance -= amount
        to_acc.balance += amount
        
        # Record transfer transaction
        transaction = Transaction(
            date=date.today(),
            amount=amount,
            type='transfer',
            category='Transfer',
            account_id=from_id,
            to_account_id=to_id,
            description=f'Transfer to {to_acc.name}',
            is_recurring=False
        )
        db.session.add(transaction)
        db.session.commit()
        flash(f'Transferred ${amount:.2f} successfully!', 'success')
    
    return redirect(url_for('accounts'))


# ============ LOANS ============
@app.route('/loans')
def loans():
    all_loans = Loan.query.filter_by(status='active').order_by(Loan.due_date).all()
    all_accounts = Account.query.all()
    return render_template('loans.html',
        active_page='loans',
        loans=all_loans,
        accounts=all_accounts
    )


@app.route('/loan/add', methods=['POST'])
def add_loan():
    due_date = datetime.strptime(request.form.get('due_date'), '%Y-%m-%d').date()
    amount = float(request.form.get('amount'))
    emi = request.form.get('emi')
    loan_type = request.form.get('type')
    adjust_balance = request.form.get('adjust_balance') == 'on'
    account_id = request.form.get('account_id')
    
    loan = Loan(
        counterparty=request.form.get('counterparty'),
        type=loan_type,
        principal_amount=amount,
        outstanding_balance=amount,
        due_date=due_date,
        emi_amount=float(emi) if emi else None,
        status='active'
    )
    db.session.add(loan)
    
    # Adjust account balance if requested
    if adjust_balance and account_id:
        account = db.session.get(Account, int(account_id))
        if account:
            if loan_type == 'given':
                account.balance -= amount  # Money lent out
            else:
                account.balance += amount  # Money borrowed in
    
    db.session.commit()
    flash('Loan record created!', 'success')
    return redirect(url_for('loans'))


@app.route('/loan/pay/<int:loan_id>', methods=['POST'])
def pay_loan(loan_id):
    loan = db.session.get(Loan, loan_id)
    if not loan:
        flash('Loan not found.', 'error')
        return redirect(url_for('loans'))
    
    amount = float(request.form.get('amount', 0))
    account_id = request.form.get('account_id')
    
    if amount <= 0:
        flash('Invalid amount.', 'error')
        return redirect(url_for('loans'))
    
    # Reduce outstanding balance
    loan.outstanding_balance -= amount
    if loan.outstanding_balance <= 0:
        loan.outstanding_balance = 0
        loan.status = 'settled'
    
    # Adjust account balance
    if account_id:
        account = db.session.get(Account, int(account_id))
        if account:
            if loan.type == 'given':
                # Receiving payment = money comes in
                account.balance += amount
            else:
                # Paying debt = money goes out
                account.balance -= amount
    
    db.session.commit()
    
    if loan.status == 'settled':
        flash(f'Loan fully settled!', 'success')
    else:
        flash(f'Payment of {amount:.2f} SAR recorded. Remaining: {loan.outstanding_balance:.2f} SAR', 'success')
    
    return redirect(url_for('loans'))


@app.route('/loan/delete/<int:loan_id>', methods=['POST'])
def delete_loan(loan_id):
    loan = db.session.get(Loan, loan_id)
    if loan:
        db.session.delete(loan)
        db.session.commit()
        flash('Loan record deleted.', 'success')
    return redirect(url_for('loans'))


# ============ AI CHAT ============
@app.route('/chat')
def chat():
    return render_template('chat.html', active_page='chat')


@app.route('/api/chat', methods=['POST'])
def chat_api():
    from services.groq_service import process_chat_command
    
    data = request.get_json()
    message = data.get('message', '')
    
    if not message:
        return jsonify({'response': 'Please enter a message.'})
    
    # Get accounts for AI context
    accounts = [a.to_dict() for a in Account.query.all()]
    
    # Process with Groq AI
    result = process_chat_command(message, accounts)
    
    response_msg = result.get('response_message', 'Done.')
    action = result.get('action', 'unknown')
    details = result.get('details', {})
    
    try:
        if action == 'transaction':
            # First check if any accounts exist
            if not accounts:
                response_msg = "You need to create an account first. Go to Accounts page to add one."
            else:
                t_type = details.get('type', 'expense')
                amount = float(details.get('amount', 0))
                category = details.get('category', 'Other')
                description = details.get('description', '')
                account_id = details.get('account_id') or accounts[0]['id']
                
                # Verify account exists in DB
                account = db.session.get(Account, int(account_id))
                if not account:
                    response_msg = "Invalid account. Please create an account first."
                else:
                    transaction = Transaction(
                        date=date.today(),
                        amount=amount,
                        type=t_type,
                        category=category,
                        account_id=int(account_id),
                        description=description,
                        is_recurring=False
                    )
                    db.session.add(transaction)
                    
                    # Update balance
                    if t_type == 'income':
                        account.balance += amount
                    else:
                        account.balance -= amount
                    
                    db.session.commit()
        
        elif action == 'transfer':
            from_id = details.get('from_account_id')
            to_id = details.get('to_account_id')
            amount = float(details.get('amount', 0))
            
            if from_id and to_id:
                from_acc = db.session.get(Account, int(from_id))
                to_acc = db.session.get(Account, int(to_id))
                
                if from_acc and to_acc:
                    from_acc.balance -= amount
                    to_acc.balance += amount
                    
                    transaction = Transaction(
                        date=date.today(),
                        amount=amount,
                        type='transfer',
                        category='Transfer',
                        account_id=int(from_id),
                        to_account_id=int(to_id),
                        description=f'AI Transfer to {to_acc.name}',
                        is_recurring=False
                    )
                    db.session.add(transaction)
                    db.session.commit()
        
        elif action == 'update_balance':
            account_id = details.get('account_id')
            amount = float(details.get('amount', 0))
            
            if account_id:
                account = db.session.get(Account, int(account_id))
                if account:
                    account.balance = amount
                    db.session.commit()
    
    except Exception as e:
        print(f"Error processing AI action: {e}")
        response_msg = "I understood your request but encountered an error processing it."
    
    return jsonify({'response': response_msg})


# ============ ADMIN ============
ADMIN_PIN = "7562"

@app.route('/admin')
def admin():
    authenticated = request.cookies.get('admin_auth') == 'true'
    
    api_key = os.getenv('GROQ_API_KEY', '')
    # Mask API key for display
    if api_key:
        api_key = api_key[:8] + '...' + api_key[-4:] if len(api_key) > 12 else '***'
    
    model = os.getenv('GROQ_MODEL', 'llama-3.3-70b-versatile')
    
    return render_template('admin.html',
        active_page='admin',
        authenticated=authenticated,
        api_key=api_key,
        model=model
    )


@app.route('/admin/auth', methods=['POST'])
def admin_auth():
    pin = request.form.get('pin', '')
    
    if pin == ADMIN_PIN:
        response = redirect(url_for('admin'))
        response.set_cookie('admin_auth', 'true', max_age=1800)  # 30 min session
        flash('Admin access granted.', 'success')
        return response
    else:
        flash('Invalid PIN.', 'error')
        return redirect(url_for('admin'))


@app.route('/admin/save', methods=['POST'])
def admin_save():
    if request.cookies.get('admin_auth') != 'true':
        return redirect(url_for('admin'))
    
    api_key = request.form.get('api_key', '')
    model = request.form.get('model', 'llama-3.3-70b-versatile')
    
    # Update .env file
    env_path = os.path.join(os.path.dirname(__file__), '.env')
    env_content = f"GROQ_API_KEY={api_key}\nGROQ_MODEL={model}\nSECRET_KEY={os.getenv('SECRET_KEY', 'finpulse-secret-key')}\n"
    
    with open(env_path, 'w') as f:
        f.write(env_content)
    
    # Reload environment
    os.environ['GROQ_API_KEY'] = api_key
    os.environ['GROQ_MODEL'] = model
    
    flash('Settings saved! Restart the server to apply changes.', 'success')
    return redirect(url_for('admin'))


@app.route('/admin/reset', methods=['POST'])
def admin_reset():
    if request.cookies.get('admin_auth') != 'true':
        return redirect(url_for('admin'))
    
    # Delete all records
    Transaction.query.delete()
    Loan.query.delete()
    Account.query.delete()
    db.session.commit()
    
    flash('Database reset complete.', 'success')
    return redirect(url_for('admin'))


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
