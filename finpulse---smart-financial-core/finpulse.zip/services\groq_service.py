import os
import json
from groq import Groq
from dotenv import load_dotenv

load_dotenv()

def get_groq_client():
    """Initialize Groq client."""
    api_key = os.getenv('GROQ_API_KEY')
    if not api_key:
        return None
    return Groq(api_key=api_key)


def get_model():
    """Get configured AI model."""
    return os.getenv('GROQ_MODEL', 'llama-3.3-70b-versatile')


def analyze_spending_spike(current_amount: float, category: str, history: list) -> dict:
    """Analyze if a transaction is an abnormal spending spike."""
    client = get_groq_client()
    if not client:
        return {'is_spike': False, 'message': ''}
    
    try:
        prompt = f"""Analyze this transaction for anomalies.
New Transaction: {category} - ${current_amount}.
Recent History for this category: {json.dumps(history)}.

Is this an abnormal spike compared to the history? 
Return JSON with exactly these fields:
- is_spike: boolean (true if this is abnormally high)
- message: string (warning message if spike, empty otherwise)"""

        response = client.chat.completions.create(
            model=get_model(),
            messages=[
                {"role": "system", "content": "You are a financial analysis assistant. Respond only with valid JSON."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
            temperature=0.3,
            max_tokens=200
        )
        
        result = json.loads(response.choices[0].message.content)
        return {
            'is_spike': result.get('is_spike', False),
            'message': result.get('message', '')
        }
    except Exception as e:
        print(f"Groq Analysis Error: {e}")
        return {'is_spike': False, 'message': ''}


def process_chat_command(message: str, accounts: list) -> dict:
    """Process natural language chat commands for financial operations."""
    client = get_groq_client()
    if not client:
        return {'action': 'error', 'message': 'AI not initialized'}
    
    try:
        accounts_info = [{'id': a['id'], 'name': a['name']} for a in accounts]
        
        prompt = f"""You are a financial assistant.
Available Accounts: {json.dumps(accounts_info)}.

User Input: "{message}"

Interpret the user's intent to perform one of these actions:
1. "transaction": Add income or expense (e.g., "Paid 50 for lunch", "Received 1000 salary").
2. "transfer": Transfer money between accounts (e.g., "Transfer 50 from cash to bank").
3. "update_balance": Adjust the balance of an account (e.g., "Set main wallet balance to 5000").
4. "loan": Record a loan/debt (e.g., "Lent 500 to Ahmed", "Borrowed 1000 from Ali", "Ahmed owes me 200").

If an account name is fuzzy, map it to the closest ID.
If no account is specified, pick the most logical one or the first one.
Currency symbols should be ignored for the amount value.

Return JSON with these fields:
- action: string ("transaction", "transfer", "update_balance", "loan", or "unknown")
- response_message: string (friendly confirmation message)
- details: object with:
  - type: string ("income" or "expense") for transactions, ("given" or "taken") for loans
  - amount: number
  - category: string (inferred category for transactions)
  - description: string
  - account_id: number (target account ID)
  - from_account_id: number (for transfers only)
  - to_account_id: number (for transfers only)
  - counterparty: string (person's name for loans)
  - due_date: string (optional, YYYY-MM-DD format, default 30 days from now)"""

        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {"role": "system", "content": "You are a financial assistant. Respond only with valid JSON."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
            temperature=0.3,
            max_tokens=500
        )
        
        result = json.loads(response.choices[0].message.content)
        return {
            'action': result.get('action', 'unknown'),
            'response_message': result.get('response_message', 'Done.'),
            'details': result.get('details', {})
        }
    except Exception as e:
        print(f"Groq Chat Error: {e}")
        return {'action': 'error', 'message': "Sorry, I couldn't process that request."}


def generate_account_summary(accounts: list, transactions: list, loans: list) -> str:
    """Generate an AI-powered financial summary."""
    client = get_groq_client()
    if not client:
        return "AI summary unavailable. Please check your API key."
    
    if not accounts:
        return "No accounts found. Create an account to get started!"
    
    try:
        # Prepare financial data
        total_balance = sum(a.get('balance', 0) for a in accounts)
        
        income_total = sum(t.get('amount', 0) for t in transactions if t.get('type') == 'income')
        expense_total = sum(t.get('amount', 0) for t in transactions if t.get('type') == 'expense')
        
        # Get expense categories
        expense_categories = {}
        for t in transactions:
            if t.get('type') == 'expense':
                cat = t.get('category', 'Other')
                expense_categories[cat] = expense_categories.get(cat, 0) + t.get('amount', 0)
        
        top_expenses = sorted(expense_categories.items(), key=lambda x: x[1], reverse=True)[:3]
        
        # Loan summary
        total_receivables = sum(l.get('outstanding_balance', 0) for l in loans if l.get('type') == 'given')
        total_payables = sum(l.get('outstanding_balance', 0) for l in loans if l.get('type') == 'taken')
        
        prompt = f"""You are a friendly financial advisor. Analyze this financial data and provide a brief, helpful summary with insights and tips.

Financial Overview:
- Total Balance across {len(accounts)} accounts: {total_balance} SAR
- This month's Income: {income_total} SAR
- This month's Expenses: {expense_total} SAR
- Net Savings: {income_total - expense_total} SAR
- Top Expense Categories: {top_expenses if top_expenses else 'None yet'}
- Money Owed to You (Receivables): {total_receivables} SAR
- Money You Owe (Payables): {total_payables} SAR

Provide a 2-3 sentence friendly summary with one actionable tip. Be concise and encouraging. Use SAR as the currency."""

        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {"role": "system", "content": "You are a helpful financial advisor. Be concise, friendly, and give practical advice."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=200
        )
        
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"Groq Summary Error: {e}")
        return "Unable to generate summary at this time."
